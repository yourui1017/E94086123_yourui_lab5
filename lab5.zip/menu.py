import pygame
import os

upgrade_menu_image = pygame.image.load(os.path.join("images", "upgrade_menu.png"))
upgrade_image = pygame.image.load(os.path.join("images", "upgrade.png"))
sell_image = pygame.image.load(os.path.join("images", "sell.png"))

class UpgradeMenu:
    def __init__(self, x, y):
        
        self.menu_image = pygame.transform.scale(upgrade_menu_image, (200, 200))
        self.upgrade_btn = pygame.transform.scale(upgrade_image, (60, 40))
        self.sell_btn = pygame.transform.scale(sell_image, (45, 40))
        self.rect = self.menu_image.get_rect()
        self.rect.center = (x, y)
        self.__buttons = [Button(self.upgrade_btn, "upgrade", self.rect.centerx, self.rect.centery - 70), 
                          Button(self.sell_btn, "sell", self.rect.centerx, self.rect.centery + 70)]  

    def draw(self, win):
        """
        (Q1) draw menu itself and the buttons
        (This method is call in draw() method in class TowerGroup)
        :return: None
        """
        # 將menu畫在menu畫布上
        menu_surface = pygame.Surface((200, 200), pygame.SRCALPHA)
        menu_surface.blit(self.menu_image,(0, 0))
        # 將menu畫布畫在主畫布上
        win.blit(menu_surface, (self.rect.centerx-100, self.rect.centery-100))
        
        # 將按鈕畫在按鈕畫布上
        botton_suface = pygame.Surface((200, 200), pygame.SRCALPHA)
        botton_suface.blit(self.upgrade_btn, (70, 10))
        botton_suface.blit(self.sell_btn, (78, 155))
        # 將按鈕畫布畫在主畫布上
        win.blit(botton_suface, (self.rect.centerx-100, self.rect.centery-100))

    def get_buttons(self):
        """
        (Q1) Return the button list.
        (This method is call in get_click() method in class TowerGroup)
        :return: list
        """
        # 將buttons回傳 
        return self.__buttons


class Button:
    def __init__(self, image, name, x, y):
        self.name = name
        self.rect = image.get_rect()
        self.rect.center = (x, y)

    def clicked(self, x, y):
        """
        (Q2) Return Whether the button is clicked
        (This method is call in get_click() method in class TowerGroup)
        :param x: mouse x
        :param y: mouse y
        :return: bool
        """
        # 如果滑鼠在圖片範圍內就會傳True
        return True if self.rect.collidepoint(x, y) else False

    def response(self):
        """
        (Q2) Return the button name.
        (This method is call in get_click() method in class TowerGroup)
        :return: str
        """
        # 將名字回傳
        return self.name






